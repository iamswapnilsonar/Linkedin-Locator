/** Automatically generated file. DO NOT MODIFY */
package com.vsplc.android.poc.linkedin;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}