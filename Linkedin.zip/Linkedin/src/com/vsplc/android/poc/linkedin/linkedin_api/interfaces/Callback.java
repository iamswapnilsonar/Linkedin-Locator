package com.vsplc.android.poc.linkedin.linkedin_api.interfaces;

public interface Callback {

	void onSucess(Object data);
	void onFailure();
}
