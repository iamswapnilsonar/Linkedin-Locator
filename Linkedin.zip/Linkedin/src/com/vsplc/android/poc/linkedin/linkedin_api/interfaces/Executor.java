package com.vsplc.android.poc.linkedin.linkedin_api.interfaces;

public interface Executor {

	void execute();
}
