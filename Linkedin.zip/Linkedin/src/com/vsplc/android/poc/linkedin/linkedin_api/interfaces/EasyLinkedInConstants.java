package com.vsplc.android.poc.linkedin.linkedin_api.interfaces;

public interface EasyLinkedInConstants {

	String SERVER_NAME = "https://www.linkedin.com/";
}
